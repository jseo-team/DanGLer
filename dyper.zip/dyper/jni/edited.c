#define cmb "czeo SYNC ..... ok."

float fug=1037.0f;

char *czeo(char* size)
{
	float width=atof(before(size,":"));
	float height=atof(after(size,":"));
	
	//progression : bar width [px]
	fug++;
	if(fug>=0.15*width)fug=0.1*width;
	
	//transmit back 
	char *result=( char* ) malloc(1024);
	sprintf(result, "%d",(int) fug);
    return result;
	
}
